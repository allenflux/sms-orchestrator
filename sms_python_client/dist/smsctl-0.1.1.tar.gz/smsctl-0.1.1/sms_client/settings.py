# project_url = "https://a2.pppkf.cc"
project_url = "http://127.0.0.1:8822"
# prefix= "/sms-api/v1/"
prefix= "/api/v1/"
url_prefix = project_url + prefix